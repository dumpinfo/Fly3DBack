enum
{
	TYPE_OBJECT=100000,
	TYPE_CAMERA,
	TYPE_LIGHT,
};

class object : public flyBspObject
{
	public:
		flyMesh* objmesh;
		flyVector color;

		flyLightVertex dynlights;

	object() :
		objmesh(0)
	{ type=TYPE_OBJECT; }

	object(const object& in) :
		flyBspObject(in),
		objmesh(in.objmesh)
	{ }

	void init();
	int step(int dt);
	void draw();
	void draw_shadow();
	int message(const flyVector& p,float rad,int msg,int param,void *data);
	int get_custom_param_desc(int i,flyParamDesc *pd);
	flyBspObject *clone()
	{ return new object(*this); }
};
class camera : public flyBspObject
{
	public:
		float movevel;
		float mousevel;

	camera() :
		movevel(0.01f),
		mousevel(0.005f)
	{ type=TYPE_CAMERA; }

	camera(const camera& in) :
		flyBspObject(in),
		movevel(in.movevel),
		mousevel(in.mousevel)
	{ }

	void init();
	int step(int dt);
	void draw();
	int message(const flyVector& p,float rad,int msg,int param,void *data);
	int get_custom_param_desc(int i,flyParamDesc *pd);
	flyBspObject *clone()
	{ return new camera(*this); }
};

class light : public flyBspObject
{
public:
	flyVector color;
	float illumradius;

	light() :
		color(1),
		illumradius(100)
	{ type=TYPE_LIGHT; }

	light(const light& in) :
		flyBspObject(in),
		color(in.color),
		illumradius(in.illumradius)
	{ }

	virtual ~light()
	{ }

	void init();
	int step(int dt);
	void draw();
	int get_custom_param_desc(int i,flyParamDesc *pd);

	flyBspObject *clone() 
	{ return new light(*this); }
};

class object_desc : public flyClassDesc
{
public:
	flyBspObject *create() { return new object; };
	const char *get_name() { return "object"; };
	int get_type() { return TYPE_OBJECT; };
};

class camera_desc : public flyClassDesc
{
public:
	flyBspObject *create() { return new camera; };
	const char *get_name() { return "camera"; };
	int get_type() { return TYPE_CAMERA; };
};

class light_desc : public flyClassDesc
{
public:
	flyBspObject *create() { return new light; };
	const char *get_name() { return "light"; };
	int get_type() { return TYPE_LIGHT; };
};