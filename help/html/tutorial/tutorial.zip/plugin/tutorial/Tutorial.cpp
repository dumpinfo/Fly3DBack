#include "../../lib/Fly3D.h"
#include "Tutorial.h"

object_desc cd_object;
camera_desc cd_camera;
light_desc cd_light;

BOOL APIENTRY DllMain(HINSTANCE hModule, 
                      DWORD  ul_reason_for_call, 
                      LPVOID lpReserved)
{    
	switch( ul_reason_for_call ) 
	{
    case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

__declspec( dllexport )
int num_classes()
{
	return 3;
}

__declspec( dllexport )
flyClassDesc *get_class_desc(int i)
{
	switch(i)
	{
	case 0:
		return &cd_object;
	case 1:
		return &cd_camera;
	case 2:
		return &cd_light;
	}
	return 0;
}

__declspec( dllexport )
int fly_message(int msg,int param,void *data)
{
	switch(msg)
	{
	case FLY_MESSAGE_INITSCENE:
		// initialize plugin
		break;
	case FLY_MESSAGE_UPDATESCENE:
		// step plugin (dt in param)
		break;
	case FLY_MESSAGE_DRAWSCENE:
		{
			g_flyengine->set_camera(g_flyengine->cam);
			g_flyengine->draw_bsp();
		}
		break;
	case FLY_MESSAGE_DRAWTEXT:
		// draw 2d plugin
		break;
	case FLY_MESSAGE_CLOSESCENE:
		// close plugin
		break;
	}
	return 1;
}

__declspec( dllexport )
int get_version()
{
	return FLY_VERSION_NUM;
}

__declspec( dllexport )
int get_global_param_desc(int i,flyParamDesc *pd)
{
	if (pd!=0)
	switch(i)
	{
	case 0:
		//pd->type=PARAM_TYPE;
		//pd->data=&PARAM_DATA;
		//pd->name="param_name";
		break;
	}
	return 0;
}

void object::init()
{
	if(objmesh)
	{
		bbox=objmesh->bbox;
		objmesh->color=color;
	}
}

int object::step(int dt)
{
	flyVector p,v;
	p=pos+vel*(float)dt;
	v=vel+force*((float)dt/mass);
	box_collision(p,v);
	pos = p;
	vel = v;
	
	g_flyengine->recurse_bsp(pos,2048,TYPE_LIGHT);
	for(int i=0;i<g_flyengine->selobjs.num;i++ )
	{
		light *l=(light *)g_flyengine->selobjs[i];

		if (g_flyengine->collision_test(pos,l->pos,FLY_TYPE_STATICMESH)==0)
			dynlights.add_light(l->pos,l->color,l->illumradius);
	}

	return 1;
}

void object::draw_shadow()
{
	int i=dynlights.get_closest(pos);
	if (i!=-1)
	{
		glPushMatrix();
		glTranslatef(pos.x,pos.y,pos.z);
		glMultMatrixf((float *)&mat);
		flyVector v=dynlights.pos[i]-pos;
		v.normalize();
		objmesh->draw_shadow_volume(v*mat_t);
		glPopMatrix();
	}
}

void object::draw()
{
	if(objmesh)
	{
		dynlights.init_draw(this);
		
		glPushMatrix();
		glTranslatef(pos.x,pos.y,pos.z);
		glMultMatrixf((float *)&mat);
		objmesh->draw();
		glPopMatrix();

		glDisable(GL_LIGHTING);
	}
}

int object::message(const flyVector& p,float rad,int msg,int param,void *data)
{
	if (msg==FLY_OBJMESSAGE_ILLUM)
		dynlights.add_light(p,*((flyVector *)data),rad);

	return 1;
}

int object::get_custom_param_desc(int i,flyParamDesc *pd)
{
	if (pd!=0)
	switch(i)
	{
		case 0:
			pd->type='m';
			pd->data=&objmesh;
			pd->name="objmesh";
		break;
		case 1:
			pd->type='c';
			pd->data=&color;
			pd->name="color";
		break;
		case 2:
			pd->type='f';
			pd->data=&color.w;
			pd->name="transp";
		break;
	}
	return 3;
}

void camera::init()
{
	bbox.min.vec(-25,-25,-25);
	bbox.max.vec(25,25,25);
}

int camera::step(int dt)
{
	if (g_flydirectx->mouse_down&FLY_MOUSE_L)
		vel=Z*movevel*(float)(-dt);
	else
		vel.null();

	if (g_flydirectx->mouse_smooth[0])	// mouse X
		rotate(-g_flydirectx->mouse_smooth[0]*mousevel,Y);

	if (g_flydirectx->mouse_smooth[1])	// mouse Y
		rotate(g_flydirectx->mouse_smooth[1]*mousevel,X);

	flyVector p,v;
	p=pos+vel*(float)dt;
	v=vel+force*((float)dt/mass);
	box_collision(p,v);
	pos = p;
	vel = v;
	
	return 1;
}

void camera::draw()
{
	// TODO: draw using opengl
}

int camera::message(const flyVector& p,float rad,int msg,int param,void *data)
{
	// TODO: process messages
	return 0;
}

int camera::get_custom_param_desc(int i,flyParamDesc *pd)
{
	if (pd!=0)
	switch(i)
	{
	case 0:
		pd->type='f';
		pd->data=&movevel;
		pd->name="movevel";
		break;
	case 1:
		pd->type='f';
		pd->data=&mousevel;
		pd->name="mousevel";
		break;
	}
	return 2;
}

void light::init()
{
	bbox.max.vec(-10,-10,-10);
	bbox.min.vec(10,10,10);
}

int light::step(int dt)
{
	return 0;
}

void light::draw()
{

}

int light::get_custom_param_desc(int i,flyParamDesc *pd)
{
	if (pd!=0)
	switch(i)
	{
		case 0:
			pd->type='c';
			pd->data=&color;
			pd->name="color";
			break;
		case 1:
			pd->type='f';
			pd->data=&illumradius;
			pd->name="illumradius";
			break;
	}
	return 2;
}